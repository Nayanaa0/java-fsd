
module camerarental {
}