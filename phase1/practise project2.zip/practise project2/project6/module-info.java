/**
 * 
 */
/**
 * 
 */
module practise6 {
}